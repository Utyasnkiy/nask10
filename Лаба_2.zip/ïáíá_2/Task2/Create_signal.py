import numpy as np
import scipy.signal


class Signal:

    def __init__(self, amplitude, frequency, phase, type_fun, prototype):
        self.amplitude = amplitude
        self.frequency = frequency
        self.phase = phase
        self.type = type_fun
        self.prototype = prototype

    def signal_x(self, sampling_rate, length):
        signal_x = np.linspace(0, length, (sampling_rate * length), endpoint=False)
        return signal_x

    def signal_y(self, sampling_rate, length):
        signal_y = None
        freq_es = self.frequency * self.signal_x(sampling_rate, length)
        if self.prototype == "digital":
            if self.type == "cos":
                signal_y = scipy.signal.square(self.amplitude * np.cos(2 * np.pi * freq_es + self.phase))
                for i in range(0, len(signal_y)):
                    if signal_y[i] < 0:
                        signal_y[i] = 0
            elif self.type == "sin":
                signal_y = scipy.signal.square(self.amplitude * np.sin(2 * np.pi * freq_es + self.phase))
                for i in range(0, len(signal_y)):
                    if signal_y[i] < 0:
                        signal_y[i] = 0
            else:
                print("Unknown type signal")
        elif self.prototype == "harmonic":
            if self.type == "cos":
                signal_y = self.amplitude * np.cos(2 * np.pi * freq_es + self.phase)
            elif self.type == "sin":
                signal_y = self.amplitude * np.sin(2 * np.pi * freq_es + self.phase)
        else:
            print("Unknown type signal")
        return signal_y


