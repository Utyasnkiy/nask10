import numpy as np
from matplotlib import pyplot as plt
import copy
from numpy.fft import rfft, rfftfreq, irfft
import scipy.signal
import Create_signal

FREQ_CARRIER = 40
FREQ_MODULATION = 4
SAMPLE_RATE = 512
DURATION = 1
PHASE = np.pi / 2
AMPLITUDE = 1
N = SAMPLE_RATE * DURATION


def create_signal_for_draw(frequency, type, prototype, phase=0, amplitude=1):
    signal = Create_signal.Signal(amplitude, frequency, phase, type, prototype)
    x = signal.signal_x(SAMPLE_RATE, DURATION)
    y = signal.signal_y(SAMPLE_RATE, DURATION)
    return signal, x, y


def amplitude_modulation(carrier_signal, modulation_signal, modulation_level):
    x = carrier_signal.signal_x(SAMPLE_RATE, DURATION)
    y = carrier_signal.signal_y(SAMPLE_RATE, DURATION)
    digit_y = modulation_signal.signal_y(SAMPLE_RATE, DURATION)
    AM_x = copy.copy(x)
    AM_y = carrier_signal.amplitude * (1 + modulation_level * digit_y) * y
    return AM_x, AM_y


def frequency_modulation(carrier_signal, modulation_signal, modulation_level):
    x = carrier_signal.signal_x(SAMPLE_RATE, DURATION)
    FM_x = copy.copy(x)
    FM_y = copy.copy(x)
    for i in range(0, len(x)):
        if modulation_signal.signal_y(SAMPLE_RATE, DURATION)[i] == 0:
            if carrier_signal.type == "cos":
                FM_y[i] = carrier_signal.amplitude * np.cos(2 * np.pi * (carrier_signal.frequency+modulation_signal.frequency)/2*FM_x[i] + carrier_signal.phase)
            else:
                FM_y[i] = carrier_signal.amplitude * np.sin(2 * np.pi * (carrier_signal.frequency+modulation_signal.frequency)/2*FM_x[i] + carrier_signal.phase)
        else:
            if carrier_signal.type == "cos":
                FM_y[i] = carrier_signal.amplitude * np.cos(2 * np.pi * carrier_signal.frequency*FM_x[i] + carrier_signal.phase)
            else:
                FM_y[i] = carrier_signal.amplitude * np.sin(2 * np.pi * carrier_signal.frequency*FM_x[i] + carrier_signal.phase)
    return FM_x, FM_y


def phase_modulation(carrier_signal, modulation_signal, modulation_level):
    x = carrier_signal.signal_x(SAMPLE_RATE, DURATION)
    PM_x = copy.copy(x)
    freq_es_carrier_sig = PM_x * carrier_signal.frequency
    modulation_signal_new = modulation_signal.signal_y(SAMPLE_RATE, DURATION)
    for i in range(0, len(modulation_signal_new)):
        if modulation_signal_new[i] == 0:
            modulation_signal_new[i] = -1
        else:
            modulation_signal_new[i] = 1
    if (carrier_signal.type == "cos"):
        PM_y = carrier_signal.amplitude * np.cos(2 * np.pi * freq_es_carrier_sig + carrier_signal.phase)*modulation_level*modulation_signal_new
    else:
        PM_y = carrier_signal.amplitude * np.sin(2 * np.pi * freq_es_carrier_sig + carrier_signal.phase)*modulation_level*modulation_signal_new
    return PM_x, PM_y


def create_spectrum(signal_y):
    spectrum_x = rfftfreq(N, 1 / SAMPLE_RATE)
    spectrum_y = rfft(signal_y)
    return sorted(spectrum_x), np.abs(spectrum_y)


def delete_low_freq(spec_y):
    max_lev = max(spec_y)
    for i in range(len(spec_y)):
        if spec_y[i] < 0.15*max_lev:
            spec_y[i] = 0
    return np.abs(spec_y)


def comparator(y):
    half = (min(y)+max(y))/2
    signal_y = copy.copy(y)
    for i in range(0, len(signal_y)):
        if signal_y[i] > half:
            signal_y[i] = 1
        else:
            signal_y[i] = 0
    return signal_y



if __name__ == '__main__':
    # Отрисовка несущего и модулирующего сигнала
    plt.subplots_adjust(left=0.1,
                        bottom=0.1,
                        right=0.9,
                        top=0.9,
                        wspace=0.4,
                        hspace=0.4)
    plt.subplot(2, 1, 1)
    plt.title("Гармонический несущий сигнал")
    carrier_signal, x, y = create_signal_for_draw(FREQ_CARRIER, "cos", "harmonic")
    plt.plot(x, y)
    modulation_signal, digit_x, digit_y = create_signal_for_draw(FREQ_MODULATION, "sin", "digital")
    plt.subplot(2, 1, 2)
    plt.title("Меандр")
    plt.plot(digit_x, digit_y)
    plt.show()
    # Отрисовка амплитудной модуляции + спектра
    plt.subplots_adjust(left=0.1,
                        bottom=0.1,
                        right=0.9,
                        top=0.9,
                        wspace=0.4,
                        hspace=0.4)
    plt.subplot(4, 1, 1)
    plt.title("Гармонический несущий сигнал")
    plt.plot(x, y)
    plt.subplot(4, 1, 2)
    plt.title("Меандр")
    plt.plot(digit_x, digit_y)
    plt.subplot(4, 1, 3)
    plt.title("Амплитудная модуляция")
    AM_x, AM_y = amplitude_modulation(carrier_signal, modulation_signal, 1)
    plt.plot(AM_x, AM_y)
    plt.subplot(4, 1, 4)
    plt.title("Спектр модуляции")
    AM_spec_x, AM_spec_y = create_spectrum(AM_y)
    plt.plot(AM_spec_x, AM_spec_y)
    plt.show()
    # Отрисовка частотной модуляции + спектра
    plt.subplots_adjust(left=0.1,
                        bottom=0.1,
                        right=0.9,
                        top=0.9,
                        wspace=0.4,
                        hspace=0.4)
    plt.subplot(4, 1, 1)
    plt.title("Гармонический несущий сигнал")
    plt.plot(x, y)
    plt.subplot(4, 1, 2)
    plt.title("Меандр")
    plt.plot(digit_x, digit_y)
    plt.subplot(4, 1, 3)
    plt.title("Частотная модуляция")
    FM_x, FM_y = frequency_modulation(carrier_signal, modulation_signal, 4)
    FM_spec_x, FM_spec_y = create_spectrum(FM_y)
    plt.plot(FM_x, FM_y)
    plt.subplot(4, 1, 4)
    plt.title("Спектр частотной модуляции")
    FM_spec_x, FM_spec_y = create_spectrum(FM_y)
    plt.plot(FM_spec_x, FM_spec_y)
    plt.show()
    # Отрисовка фазовой модуляции + спектра
    plt.subplots_adjust(left=0.1,
                        bottom=0.1,
                        right=0.9,
                        top=0.9,
                        wspace=0.4,
                        hspace=0.4)
    plt.subplot(4, 1, 1)
    plt.title("Гармонический несущий сигнал")
    plt.plot(x, y)
    plt.subplot(4, 1, 2)
    plt.title("Меандр")
    plt.plot(digit_x, digit_y)
    plt.subplot(4, 1, 3)
    plt.title("Фазавая модуляция")
    PM_x, PM_y = phase_modulation(carrier_signal, modulation_signal, 1)
    plt.plot(PM_x, PM_y)
    plt.subplot(4, 1, 4)
    plt.title("Спектр фазовой модуляции")
    PM_spec_x, PM_spec_y = create_spectrum(PM_y)
    plt.plot(PM_spec_x, PM_spec_y)
    plt.show()
    # Амплитудная модуляция из спектра + Амплитудная демодуляция
    plt.subplots_adjust(left=0.1,
                        bottom=0.1,
                        right=0.9,
                        top=0.9,
                        wspace=0.4,
                        hspace=0.4)
    plt.subplot(6, 1, 1)
    plt.title("Амплитудная модуляция")
    plt.plot(AM_x, AM_y)
    plt.subplot(6, 1, 2)
    plt.title("Спектр амплитудной модуляции")
    AM_spec_x, AM_spec_y = create_spectrum(AM_y)
    plt.plot(AM_spec_x, AM_spec_y)
    plt.subplot(6, 1, 3)
    plt.title("Cпектр основных частот амплитудной модуляции")
    AM_spec_y_filt = delete_low_freq(AM_spec_y)
    plt.plot(AM_spec_x, AM_spec_y_filt)
    plt.subplot(6, 1, 4)
    plt.title("Амплитудная модуляция из спектра")
    gen_y = irfft(AM_spec_y_filt)
    plt.plot(x, gen_y)
    plt.subplot(6, 1, 5)
    plt.title("Амплитудная демодуляция")
    Mod_y = scipy.signal.hilbert(gen_y)
    plt.plot(x, gen_y, "--k")
    plt.plot(x, np.abs(Mod_y))
    plt.subplot(6, 1, 6)
    Mod_y_comp = comparator(np.abs(Mod_y))
    plt.title("Восстановленный модулирующий сигнал")
    plt.plot(x, np.abs(Mod_y_comp))
    plt.show()


